public interface Dance
{
  String getName();
  String getSteps(int m);
  int[] getBeat();
}
